package org.example;

public class SmallestLargestNumberArray {
    public static void findSmallLarge(int[] num){
        int temp =0;
        int small =0;
        for(int i=0;i< num.length;i++){
            if(temp < num[i]){
                temp = num[i];
            }
        }
        System.out.println("Largest Number is "+temp);
        for(int i=0;i< num.length;i++){
            if(temp > num[i] && (small == 0 || small > num[i])){
                small = num[i];
            }
        }
        System.out.println("Small Number is "+small);
    }
}
