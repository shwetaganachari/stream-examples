package org.example;

public class Main {
    public static void main(String[] args) {

      /* String name= ReverseString.reverse("Veena");
        System.out.println("name: "+ name);*/
      /* String palindrome= CheckPalindrome.palindrome(4663);
        System.out.println("palindrome: "+ palindrome);*/
       // SwappingNumbers.swap(60,50);
        int[] num={11,2,3,4,5,6,9,10};
    //    OddNumbers.oddNumber(num);
        //PrimeNumber.prime(num);
      //  SecondLargestNumber.secondLargeNum(num);
      //  VowelInString.vowel("Veena");
    //    DuplicateElementsInArray.findDuplicate("madam");
     //   FebonacciSeries.getSeries();
      //  RemoveSpaceInString.removeSpace("Hello world! How are you?");
        //SmallestLargestNumberArray.findSmallLarge(num);
        DuplicateCharInString.removeDuplicate("programing");
    }
}