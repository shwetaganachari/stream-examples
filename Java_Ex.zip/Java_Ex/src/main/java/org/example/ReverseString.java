package org.example;

public class ReverseString {

    public static String reverse(String name){
        char[] charArray= new char[name.length()];
        char[] reverseArray = new char[name.length()];
        for(int i=0;i<name.length();i++){
            charArray[i] = name.charAt(i);
            System.out.println("charArray: "+ charArray[i]);

          //  System.out.println("reverseArray: "+ reverseArray[j]);
        }
        System.out.println("charArray.length: "+ charArray.length);

        for(int i=0;i<charArray.length;i++){
            reverseArray[i] = charArray[(charArray.length-1)-i];
            System.out.println("reverseArray: "+ reverseArray[i]);

            //  System.out.println("reverseArray: "+ reverseArray[j]);
        }
        return  String.valueOf(reverseArray);

    }
}
