package org.example;

public class DuplicateElementsInArray {
    public static void findDuplicate(String word){
       char[] wordArray = word.toCharArray();
       for(int i=0; i<wordArray.length;i++){
            for(int j=i+1; j<wordArray.length;j++){
                if(wordArray[i] == wordArray[j]){
                    System.out.println("duplicate words are: "+wordArray[i]);
                }
            }
       }
    }
}
