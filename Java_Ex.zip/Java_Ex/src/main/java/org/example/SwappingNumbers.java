package org.example;

public class SwappingNumbers {

    public static void swap(int a, int b){
        int temp;
        if(a != 0 && b != 0){
            temp =a;
            a=b;
            b=temp;
        }
        System.out.println("swapping numbers: "+a+ +b);
    }
}
