package org.example;

public class OddNumbers {
    public static int[] oddNumber(int[] num){
        int[] odd=new int[num.length];
        for (int i=0;i<num.length;i++){
            if(num[i]%2 != 0){
              odd[i] = num[i];
              System.out.println("odd number: "+odd[i]);
            }
        }
    return odd;
    }
}
