package org.example;

public class FebonacciSeries {

    public static void getSeries(){
        int[] a=new int[10];
        a[0] =0;
        a[1]=1;
        System.out.println("febonacci series: "+a[0]);
        System.out.println("febonacci series: "+a[1]);
        for (int i=2;i<a.length;i++ ){
            a[i] = a[i-1] + a[i-2];
            System.out.println("febonacci series: "+a[i]);
        }
    }
}
