package org.example;

public class RemoveSpaceInString {
    public static void removeSpace(String word){
        char[] w=word.toCharArray();
        StringBuffer sb= new StringBuffer();
        for(int i=0; i< w.length;i++){
            if(w[i] != ' '){
                sb.append(w[i]);
            }

        }
        System.out.println("string is: "+sb);
    }
}
