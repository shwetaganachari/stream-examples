package org.example;

public class CheckPalindrome {

    public static String palindrome(Object parameter){
        if(parameter instanceof Integer){
            Integer number=(Integer)parameter;
            return validatePalidrome(String.valueOf(number));
        }
        if(parameter instanceof String){
            String name = (String)parameter;
            return validatePalidrome(name);
        }
        return null;
    }

    private static String validatePalidrome(String name){
        StringBuilder sb= new StringBuilder();

     char[] pname=name.toCharArray();
     for (int i= pname.length-1;i>=0;i--){
         sb.append(pname[i]);
     }
        System.out.println("sb: "+ sb);
        System.out.println("name: "+ name);
     if(name.contentEquals(sb)){
         return "It's Palindrome: ";
     }else{
         return "It's not a Palindrome: ";
     }
    }
}
