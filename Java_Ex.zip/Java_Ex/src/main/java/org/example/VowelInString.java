package org.example;

public class VowelInString {
    public static void vowel(String word){
        char[] wordArray=word.toCharArray();
        char[] vowel = {'a','e','i','o','u'};
        char[] v = new char[word.length()];
        for (int i=0;i<wordArray.length;i++){
            for(int j=0; j< vowel.length;j++){
                if(wordArray[i] == vowel[j]){
                    v[i] = wordArray[i];
                    System.out.println("vowels are: "+v[i]);
                }
            }
        }
    }
}
