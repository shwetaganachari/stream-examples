package org.example;

public class SecondLargestNumber {
    public static void secondLargeNum(int[] num){
        int firstLarge = 0;
        int secondLarge =0;
        for(int i=0;i<num.length;i++){

            if(num[i] > firstLarge){
                secondLarge = firstLarge;
                firstLarge = num[i];
            } else if (num[i] > secondLarge && num[i] != firstLarge) {
                secondLarge = num[i];
            }
        }
        System.out.println("large number: "+secondLarge);
    }
}
