package org.example;

import java.util.LinkedHashSet;

public class DuplicateCharInString {
    public static void duplicateChar(String word){
        LinkedHashSet<Character> ls= new LinkedHashSet<>();
        StringBuffer sb= new StringBuffer();
        for(char c: word.toCharArray()){
            ls.add(c);
        }
        for(char d:ls)
        {
            sb.append(d);
        }
        System.out.println("word is : "+sb);
    }

    public static void removeDuplicate(String word){
        StringBuffer sb= new StringBuffer();
        boolean[] seen = new boolean[256];
        for (char c: word.toCharArray()){
            if(!seen[c]){
                sb.append(c);
                seen[c]= true;
            }
        }

        System.out.println("word is : "+sb);
    }
}
