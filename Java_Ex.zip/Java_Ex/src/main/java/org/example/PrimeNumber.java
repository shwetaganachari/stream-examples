package org.example;

public class PrimeNumber {
    public static void prime(int[] num){
        int[] pnum= new int[num.length];
       for(int i = 0;i< num.length;i++){
           boolean p=checkPrime(num[i]);
           if(p){
               pnum[i] = num [i];
               System.out.println("prime numbers are:: "+pnum[i]);
           }

       }
    }
    public static boolean checkPrime(int num){
        if(num <= 1){
            return false;
        }else{
            for (int i=2; i<=num/2 ; i++){
                if(num % i == 0){
                 return false;
                }
            }
        }
        return true;
    }
}
