package lambda;

public class Ola implements Cab{
    public boolean bookCab(String name, int num){
        System.out.println("cab is booked");
        return true;
    }
}
