package lambda;

import java.util.ArrayList;
import java.util.function.Function;

public class FunctionInterfaceExample {

    public static void main(String args[]){
        Function<Integer,Integer> f= i -> i+10;
        System.out.println("result: "+f.apply(20));
        Function<String,String> f1= s -> {
          if(s.length() > 5) {
              return s;
          }
          return "string length is less than 5";
        };
        System.out.println("result: "+f1.apply("Hello World"));

        Function<String,Integer>f3= s-> s.length();
        System.out.println("result: "+f3.apply("Hello World"));
        ArrayList<Employee> empArray=new ArrayList<>();
        empArray.add(new Employee(1,"Shweta",10000));
        empArray.add(new Employee(2,"John",20000));
        empArray.add(new Employee(3,"David",30000));
        empArray.add(new Employee(4,"karna",40000));
        Function<Employee,Integer> f4= e-> {
            if(e.salary > 10000 && e.salary <20000){
                return e.salary * 10/100;
            }else if(e.salary > 20000 && e.salary <30000){
                return e.salary * 20/100;
            }else{
                return e.salary * 30/100;
            }
        };
        for(Employee e:empArray){
         int bonus = f4.apply(e);
            System.out.println("Emp Nme "+e.name+ "Salary "+e.salary+" bonus "+bonus);
        }
        //function chaining using addThen(), compose() methods of function interface
        //f5-> s.length()
        //f6->i >10

        Function<String,Integer> f5= s->s.length();
        Function<Integer,String> f6= i-> {
            if(i>5){
                return "length is greater than 5";
            }
            return null;
        };
        //addThen() -> 1st f5 will be executed and returned value will be passed to f6
        if(f5.andThen(f6).apply("Hello world") != null){
            System.out.println("inside add then if "+f5.andThen(f6).apply("Hello world"));
        }
        //compose -> 1st f6 will be executed then result will be passed to f5.
        //Basically it's reverse of addThen()
        if(f5.compose(f6).apply(10) != null){
            System.out.println("inside compose if "+f5.compose(f6).apply(10));
        }
    }
}
