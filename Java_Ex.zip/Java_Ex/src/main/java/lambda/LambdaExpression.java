package lambda;


import java.util.function.Predicate;

//custom functional interface
//functional interface --> interface having only one abstract method
//functional interface can have default and static methods but only one astract method is allowed
interface Cab{
    public boolean bookCab(String name, int num);

    default void m1(){
        System.out.println("inside m1");
    }
     static void m2(){
         System.out.println("inside m2");
    }
}

public class LambdaExpression {

    public static void main(String args[]){
       // System.out.println("Hello world");
        //if multiple lines we can use {}, or write it in single line
        //we can use return when multiple statements are present or else no need
        Cab cab = (a,b)-> (a.length() > 5 && b < 10);
        System.out.println("cab is booked :"+cab.bookCab("shweta", 10));
    }
}
