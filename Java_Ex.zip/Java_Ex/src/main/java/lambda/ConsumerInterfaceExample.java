package lambda;

import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
//consumer will accept only one argument and will not return anything
public class ConsumerInterfaceExample {

    public static void main(String arrgs[]){
        Consumer<String> c = s-> System.out.println(s);
        c.accept("My name is Cow");
        ArrayList<Employee> empArray=new ArrayList<>();
        empArray.add(new Employee(1,"Shweta",10000));
        empArray.add(new Employee(2,"John",20000));
        empArray.add(new Employee(3,"David",30000));
        empArray.add(new Employee(4,"karna",40000));
        Function<Employee, Integer> f = emp ->{ //to calculate the bonus and return bonus
            if(emp.salary > 10000 && emp.salary <20000){
               return emp.salary *10/100;
            }else{
                return emp.salary *20/100;
            }
        };
        Predicate<Integer> p= i-> i>5000;// To check if bonus is greater than 5000
        Consumer<Employee> c1= emp->{
            System.out.println(emp.salary);
            System.out.println(emp.name);
            System.out.println(emp.id);
        };
        for (Employee e:empArray){
           int bonus= f.apply(e);
           if(p.test(bonus)){
               c1.accept(e);// just to print the values
               System.out.println("bonus "+bonus);
           }
        }

        //consumer chaining
        Consumer<String> c2= s-> System.out.println(s+" is white");
        Consumer<String> c3= s-> System.out.println(s+" has four legs");
        Consumer<String> c4= s-> System.out.println(s+" and having grass");
        c2.andThen(c3).andThen(c4).accept("Cow");

        // consumer chaining with consumer interface
        Consumer<String> c5= c2.andThen(c3).andThen(c4);
        c5.accept("cow");
    }
}
