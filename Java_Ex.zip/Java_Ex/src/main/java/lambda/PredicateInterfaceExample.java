package lambda;

import java.util.ArrayList;
import java.util.function.Predicate;

public class PredicateInterfaceExample {

    public static void main(String args[]){
        Predicate<Integer> p= i -> i<10;
        if(p.test(5)){
            System.out.println("number is less than 10");
        }

        Predicate<String> p1= s -> s.length()>10;
        if(p1.test("Hello World")){
            System.out.println("String length is greater than 10");
        }
        //user defined classes
        Employee e1= new Employee(1,"Shweta",10000);
        Employee e2= new Employee(2,"John",20000);
        Employee e3= new Employee(3,"David",30000);
        Employee e4= new Employee(4,"karna",40000);
        ArrayList<Employee> empArray=new ArrayList<>();
        empArray.add(e1);
        empArray.add(e2);
        empArray.add(e3);
        empArray.add(e4);
        Predicate<Employee> p3= e -> e.salary < 40000;
        for (Employee e: empArray){
         if(p3.test(e)){
             System.out.println("employee name: "+ e.name);
         }
        }
        //combining two predicates using and, or, negate operators
        int a[]={5,10,15,20,25,30,35};
        Predicate<Integer> a1 = i1 ->i1 %2 ==0;
        Predicate<Integer> a2 = i2 ->i2 > 20;
        /*for(Integer i3:a){
            if(a1.test(i3) && a2.test(i3)){
                System.out.println("number is "+i3);
            }
        }*/
        for(Integer i3:a){
            if(a1.and(a2).test(i3)){
                System.out.println("number is "+i3);
            }
        }
        for(Integer i3:a){
            if(a1.or(a2).test(i3)){
                System.out.println("number is "+i3);
            }
        }
        for(Integer i3:a){
            if(a1.negate().test(i3)){
                System.out.println("number is "+i3);
            }
        }
    }
}
