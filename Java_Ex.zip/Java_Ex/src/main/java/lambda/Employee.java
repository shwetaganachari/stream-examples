package lambda;

public class Employee {
    int id;
    String name;
    public int salary;

    public Employee(int id,String name,int salary){
        this.id =id;
        this.name=name;
        this.salary=salary;
    }
}
