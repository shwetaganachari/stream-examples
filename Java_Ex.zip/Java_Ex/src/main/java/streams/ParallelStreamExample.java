package streams;


import lambda.Employee;

import java.util.Arrays;
import java.util.List;

public class ParallelStreamExample {
    public static void main(String[] args) {
        List<Employee> employeeList= Arrays.asList(new Employee(1,"Shweta", 10000),
                new Employee(2, "Veena", 20000),
                new Employee(3,"David", 35000),
                new Employee(4,"John", 15000));

        //parallelStream()
        employeeList.parallelStream().filter(s->s.salary >20000).limit(1).forEach(s->
                System.out.println(s.salary));

        //parallel() method from Streams to create parallelStream()
        employeeList.stream().parallel().filter(s->s.salary < 20000).limit(2).forEach(s->
                System.out.println(s.salary));

    }
}
