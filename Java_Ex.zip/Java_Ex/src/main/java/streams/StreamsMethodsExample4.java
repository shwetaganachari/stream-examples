package streams;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class StreamsMethodsExample4 {
    public static void main(String[] args) {
        List<String> names= Arrays.asList("Shweta","Veena","David","John");
        //findFirst()
        Optional<String> name=names.stream().findFirst();
        System.out.println(name.get());

        //findAny()
        Optional<String> n=names.stream().findAny();
        System.out.println(n.get());


    }
}
