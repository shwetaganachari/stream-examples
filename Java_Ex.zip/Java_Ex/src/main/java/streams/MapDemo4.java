package streams;

import lambda.Employee;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

//Using Both Filter and Map
public class MapDemo4 {
    public static void main(String[] args) {
     List<Employee> employeeList= Arrays.asList(new Employee(1,"Shweta",10000),
             new Employee(2,"John",20000),
             new Employee(3,"David",30000),
             new Employee(4,"karna",40000));
        List<Integer> emp= employeeList.stream().filter(e->e.salary > 20000).map(e->e.salary).collect(Collectors.toList());
        System.out.println(emp);
    }
}
