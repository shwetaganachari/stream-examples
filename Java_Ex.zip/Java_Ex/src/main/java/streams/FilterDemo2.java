package streams;

import java.util.Arrays;
import java.util.List;

public class FilterDemo2 {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("Hello", "World","Shweta","VeenaGr");
       // words.stream().filter(s-> s.length() > 6).forEach(s-> System.out.println(s));
        words.stream().filter(s->s.length()>6).forEach(System.out::println);
    }
}
