package streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
//flapMap method is used to process complex collections
public class FlatMapDemo1 {
    public static void main(String[] args) {
        List<Integer> arr1= Arrays.asList(1,2,3);
        List<Integer> arr2= Arrays.asList(4,5,6);
        List<Integer> arr3= Arrays.asList(7,8,9);
        List<List<Integer>> arrList=Arrays.asList(arr1,arr2,arr3);
        List<Integer> totalNumbers=arrList.stream().flatMap(i->i.stream()).collect(Collectors.toList());
        System.out.println(totalNumbers);
    }
}
