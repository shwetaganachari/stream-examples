package streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
//Example to use flap map and map
//here fetching name of product using map
public class FlatMapDemo3 {
    public static void main(String[] args) {
        List<Product> productList1 = new ArrayList<>();
        productList1.add(new Product(1,"Sony",30000));
        productList1.add(new Product(2,"Dell",38000));
        productList1.add(new Product(3,"Lenavo",25000));
        productList1.add(new Product(4,"Apple",90000));

        List<Product> productList2 = new ArrayList<>();
        productList2.add(new Product(5,"HP",35000));
        productList2.add(new Product(6,"Ascer",28000));
        productList2.add(new Product(7,"ThinkPad",25000));
        productList2.add(new Product(8,"jboss",100000));

        List<List<Product>> productList= Arrays.asList(productList1,productList2);
        List<String> pnames=productList.stream().flatMap(p->p.stream()).map(s->s.name).collect(Collectors.toList());
        System.out.println(pnames);

    }
}
