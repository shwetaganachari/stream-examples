package streams;

import java.util.ArrayList;
import java.util.List;

class Product{
    int poductId;
    String name;
    int price;
    Product(int poductId,String name,int price){
        this.poductId=poductId;
        this.name=name;
        this.price=price;
    }
}
public class FilterDemo4 {
    public static void main(String[] args) {
        List<Product> productList = new ArrayList<>();
        productList.add(new Product(1,"Sony",30000));
        productList.add(new Product(2,"Dell",38000));
        productList.add(new Product(3,"Lenavo",25000));
        productList.add(new Product(4,"Apple",90000));

        productList.stream().filter(p->p.price >=30000).forEach(p->System.out.println(p.price));

    }
}
