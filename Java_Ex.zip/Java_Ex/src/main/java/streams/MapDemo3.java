package streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MapDemo3 {
    public static void main(String[] args) {
        List<Integer> num= Arrays.asList(10,20,30,40,50,60);
        List<Integer> nums=num.stream().map(i-> i*3).collect(Collectors.toList());
        System.out.println(nums);
    }
}
