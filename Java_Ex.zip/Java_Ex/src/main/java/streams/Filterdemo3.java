package streams;

import java.util.Arrays;
import java.util.List;
//adding two conditions in Filter method
public class Filterdemo3 {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("Hell", "World","Shweta","VeenaGr");
        words.stream().filter(s-> s.length() >4 && s.length() <6).forEach(System.out::println);
    }
}
