package streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMapDemo2 {
    public static void main(String[] args) {
        List<String> name1= Arrays.asList("Shweta","John","kathy");
        List<String> name2= Arrays.asList("Veena","David","Marry");
        List<String> name3= Arrays.asList("Kana","Radha","Rama");
        List<List<String>> names=Arrays.asList(name1,name2,name3);
        List<String> nameList=names.stream().flatMap(i-> i.stream()).collect(Collectors.toList());
        System.out.println(nameList);
    }
}
