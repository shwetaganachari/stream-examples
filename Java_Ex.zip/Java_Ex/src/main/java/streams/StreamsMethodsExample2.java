package streams;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
//sorted
public class StreamsMethodsExample2 {
    public static void main(String[] args) {
        List<String> names= Arrays.asList("Shweta","Aman","David","carel","Emily");
        /*List<String> sortedNames=names.stream().sorted().collect(Collectors.toList());
        System.out.println(sortedNames);*/
        //reverse order
        List<String> sortedNames=names.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        System.out.println(sortedNames);


    }
}
