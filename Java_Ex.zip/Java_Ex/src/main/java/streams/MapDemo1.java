package streams;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

//covert string to upper case
public class MapDemo1 {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("john", "David","Shweta","mary");
        words.stream().map(s-> s.toUpperCase()).forEach(System.out::println);
    }
}
