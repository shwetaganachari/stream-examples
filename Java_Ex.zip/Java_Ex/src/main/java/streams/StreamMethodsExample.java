package streams;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
//examples for terminal and non terminal methods
public class StreamMethodsExample {
    public static void main(String[] args) {
        //to get distinct values
        List<String> words = Arrays.asList("Shweta","World","Shweta","World");
        List<String> uniqueWords=words.stream().distinct().collect(Collectors.toList());
        System.out.println(uniqueWords);

        //to get minimum value
        List<Integer> nums = Arrays.asList(10,20,35,45);
        Optional<Integer> op=nums.stream().min((val1, val2)-> val1.compareTo(val2));
        System.out.println(op.get());

        long d=nums.stream().filter(i-> i%2==0).count();
        System.out.println("even numbers: "+d);

        //count
        long c=nums.stream().count();
        System.out.println(c);

        //maximum value
        Optional<Integer> o= nums.stream().max((val1,val2)-> val1.compareTo(val2));
        System.out.println(o.get());

        //limit
        List<Integer> result=nums.stream().limit(2).collect(Collectors.toList());
        System.out.println(result);

        //reduce
        List<String> ex=Arrays.asList("A","B","C","1","2","3");
        Optional<String> res=ex.stream().reduce((i,a )-> i+a);
        System.out.println(res.get());

        //toArray
        Object[] ar=nums.stream().toArray();
        for(Object o1:ar){
        System.out.println(o1);
        }

    }

}
