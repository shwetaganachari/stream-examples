package streams;

import java.util.*;

public class StreamsMethodsExample3 {
    public static void main(String[] args) {
        Set<String> names = new TreeSet<>();
        names.add("One banana");
        names.add("One apple");
        names.add("Two grapes");
        names.add("Two custardApple");
        names.add("Three watermelon");
        //anyMatch()
        boolean filteredNames = names.stream().anyMatch(s-> s.startsWith("One"));
        System.out.println("filteredNames: "+filteredNames);

        //allMatch()
        filteredNames = names.stream().allMatch(s-> s.startsWith("One"));
        System.out.println("filteredNames: "+filteredNames);

        //noneMatch()
        boolean noneMatch = names.stream().noneMatch(s-> s.startsWith("One"));
        System.out.println("noneMatch: "+noneMatch);

    }
}
